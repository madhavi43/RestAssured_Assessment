package uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class verifyaccount extends RestAssuredBase{
	
	@Test(dependsOnMethods= {"uibank.Login.login"})
	public void verifyaccount()
	{
		//Step 1:Assigning URL to RestAssured BAseURI
		RestAssured.baseURI="https://uibank-api.azurewebsites.net/api/accounts";
		
		//Step 2:Verifying the account details
		Response response = RestAssured.given()
				.queryParams("filter[where][userId]", "620f1dd78932d4005f2a8877")
				.header("authorization",id).get();
		
		//Step 3:verifying the account deatils based on "friendlyname"
		JsonPath path=response.jsonPath();
		String object = path.get("friendlyName").toString();
		if(object.contains("testaccount1"))
		{
			System.out.println("account created succesfully");
		}
		
		//Step 4 :printing the status code.
		System.err.println(response.statusCode());
		
	}

}
