package uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class createaccount extends RestAssuredBase{
	
	@Test(dependsOnMethods= {"uibank.Login.login"})
	public void createaccount()
	{
		//Step 1:Assigning Base Url to RestAssure baseURI
		RestAssured.baseURI="https://uibank-api.azurewebsites.net/api/accounts";
		
		//Step 2:creating a new account "testaccount1 where authorization specified in header request.
		Response response = RestAssured.given().header("authorization",id)
		.contentType(ContentType.JSON).body(""
				+ "{\"friendlyName\":\"testaccount1\",\"type\":\"savings\",\"userId\":\"620f1dd78932d4005f2a8877\",\"balance\":100,\"accountNumber\":60457124}")
		.post();
		
		//Step3:printing the response and status code.
		response.prettyPrint();
		System.err.println(response.statusCode());
	}

}
